class MarkdownRender:
    def __init__