from PySide6.QtWidgets import QWidget

class LineNumber(QWidget):
    def __init__(self):
        pass
