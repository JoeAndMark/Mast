class MarkdownRender:
    def 