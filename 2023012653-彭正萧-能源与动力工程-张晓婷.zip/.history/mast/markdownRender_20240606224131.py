class MarkdownRender:
    def __init__(self):
        pass